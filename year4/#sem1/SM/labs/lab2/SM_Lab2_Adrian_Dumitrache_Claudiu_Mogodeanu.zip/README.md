# Laborator 2 SM

Laborator realizat de:

* Dumitrache Adrian-George (342C1)
* Mogodeanu Claudiu (342C1)

Interval de laborator: Vineri 16-18
