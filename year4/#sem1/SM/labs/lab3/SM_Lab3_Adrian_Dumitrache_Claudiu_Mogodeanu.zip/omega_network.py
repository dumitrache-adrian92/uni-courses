import sys

def shuffle(x, n):
    return (2 * x + (2 * x) // n) % n

def get_bit(x, idx):
    return (x >> idx) & 1

if __name__ == '__main__':
    k = int(input("k = "))
    if k < 3:
        print("k must be greater than or equal to 3")
        sys.exit()

    m = int(input("m = "))
    N = 2 ** k

    for _ in range(m):
        source, destination = map(int, input().split())
        value = source

        for i in range(k):
            new_value = shuffle(value, N)

            if get_bit(destination, k - i - 1) == 0:
                print(value, "->", new_value, ", block", new_value // 2, "direct")
            else:
                new_value = new_value - 1 if new_value % 2 else new_value + 1

                print(value, "->", new_value, "block", new_value // 2, "cross")

            value = new_value
