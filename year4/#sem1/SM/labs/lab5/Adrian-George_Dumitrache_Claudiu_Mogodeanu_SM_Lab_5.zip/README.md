# Laborator 5 SM

Laborator realizat de:

* Dumitrache Adrian-George (342C1)
* Mogodeanu Claudiu (342C1)

Am implementat algoritmul Odd Even Transposition Sort utilizand urmatoarele
operatii:

* scatter pentru a distribui vectorul de la lider la task-uri
* send/recv pentru transmiterea de valori in cadrul algoritmului OETS
* gather pentru a aduna toate valorile la lider si a le afisa
