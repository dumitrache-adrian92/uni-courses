import threading
import os

from multiprocessing.connection import Listener
from threading import Lock

class GpsDevice():
    data = {
        "time": "undefined",
        "latitude": 0,
        "longitude": 0,
    }

    def __init__(self):
        self.running = True
        self.socket_path = '/tmp/gps_socket'
        if os.path.exists(self.socket_path):
            os.remove(self.socket_path)
        self.listener = Listener(self.socket_path, authkey=b'test', family='AF_UNIX')
        self.lock = Lock()
        # Start the update process in a background thread
        self.thread = threading.Thread(target=self._update_value, daemon=True)
        self.thread.start()

    def _update_value(self):
        conn = self.listener.accept()

        while self.running:
            msg = conn.recv()

            with self.lock:
                self.data = msg
                print(f"Received: {self.data}")

    def get_data(self):
        with self.lock:
            print(f"Returning: {self.data}")
            return self.data

    def stop(self):
        self.listener.close()
        self.running = False
        self.thread.join()
