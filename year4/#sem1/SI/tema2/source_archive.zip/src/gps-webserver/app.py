from flask import Flask
from flask import render_template, jsonify

from gps import GpsDevice


app = Flask(__name__)
gps = GpsDevice()

@app.route("/update")
def update():
    return jsonify(gps.get_data())

@app.route("/")
def main_page():
    data = gps.get_data()
    return render_template('index.html', data=data)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=80, debug=True)
