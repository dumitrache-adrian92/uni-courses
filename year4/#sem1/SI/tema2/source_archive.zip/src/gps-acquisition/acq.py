from datetime import datetime
from multiprocessing.connection import Client
from time import sleep

import serial

def convert_to_decimal_degrees(nmea_degrees, indicator):
    digit_count = 2 if nmea_degrees.find('.') == 4 else 3

    degrees = float(nmea_degrees[:digit_count])
    minutes = float(nmea_degrees[digit_count:])

    decimal_degrees = degrees + minutes / 60

    if indicator in set(['S', 'W']):
        decimal_degrees *= -1

    return decimal_degrees

lat = 0
lon = 0
dt = None

updated_time = False
updated_position = False

if __name__ == "__main__":
    serial = serial.Serial(
        port='/dev/ttyUSB0',
        baudrate=9600,
    )

    SOCKET_PATH = '/tmp/gps_socket'
    conn = None
    while conn is None:
        try:
            conn = Client(SOCKET_PATH, authkey=b'test', family='AF_UNIX')
        except:
            sleep(3)

    while True:
        LINE = str(serial.readline())[2:-1]

        data = LINE.strip().split(',')

        msg_type = data[0]

        if msg_type == '$GPGGA':
            lat = data[2]
            ns_indicator = data[3]
            lon = data[4]
            ew_indicator = data[5]

            lat = convert_to_decimal_degrees(lat, ns_indicator)
            lon = convert_to_decimal_degrees(lon, ew_indicator)

            updated_position = True
        elif msg_type == '$GPZDA':
            utc_time = data[1]
            day = data[2]
            month = data[3]
            year = data[4]

            # get datetime object
            dt = datetime.strptime(utc_time, '%H%M%S.%f')
            dt = dt.replace(day=int(day), month=int(month), year=int(year))

            updated_time = True

        if updated_position and updated_time:
            print("Sending data")
            print(f"Latitude: {lat}, Longitude: {lon}, Time: {dt.strftime('%Y-%m-%d %H:%M:%S')}")
            conn.send({
                "latitude": round(lat, 4),
                "longitude": round(lon, 4),
                "time": dt.strftime('%Y-%m-%d %H:%M:%S')
            })

            updated_position = False
            updated_time = False
