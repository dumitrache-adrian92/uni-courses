Readme Tema 2 SI 2024-2025
-------------------------------------------------------------------------------
Adrian-George DUMITRACHE, 342C1
-------------------------------------------------------------------------------

Noroc, incepand cu inceputul, am folosit buildroot pentru rootfs si am compilat
kernel-ul manual (nu prin buildroot).

Setarile importante din menuconfig-ul buildroot-ului:
- arch = AARCH64
- arch variant = cortex-A53
- floating point strategy = VFPv4
- root password = "tema2"
- hostname = "tema2"
- overlay = rootfs_overlay din arhiva aceasta
- pachete precum:
    - avahi mdns daemon
    - python3 (+ flask si pyserial)

Si din kernel (bazat pe defconfig):
- LOCALVERSION = "-si-adrian.dumitrache02"
- MODULES = n
- setarile de arhitectura obisnuite

Overlay-ul contine:
- config-ul ssh pentru a permite conectarea la root
- codul sursa pentru serverul web si daemon-ul de GPS
- script-uri de init ce pornesc cele 2 servici

Script-urile sunt destul de dragute, permit si oprirea/repornirea serviciilor,
bazandu-se pe salvarea PID-ului intr-un fisier `.pid` in `/run/`. Imi place sa
scriu shell scripts, pacat ca nu ma plateste nimeni pentru asta, poate la
pensie.

In acest moment avem setup-ul pentru a porni Linux in QEMU si script-uri ce ne
pot porni serviciile automat, ramane sa discutam serviciile propriu zise.
Le-am scris pe ambele in Python pentru ca:
1. sunt lenes
2. no cross compiling
3. pentru a utiliza din plin resursele unui raspberry pi :) (cope)

Serverul utilizeaza framework-ul Flask pentru a servi 2 rute mari si late:
- `/` - serveste pagina principala
- `/update` - returneaza un json cu cel mai recent set de date (latitudine,
longitudine, data + timp)

Pagina principala e doar un amarat de HTML aproape static, similar cu exemplul.
Pentru a asigura ca aceasta arata cele mai recente date pe care le are
serverul, HTML-ul are embedded (hehe) un script care face requesturi la ruta
de `/update` o data la o secunda si actualizeaza pagina cu datele noi. Acesta
este si scopul principal pentru care exista aceasta ruta.

Serverul preia date noi intr-un thread separat de la daemonul GPS cu care
comunica prin modulul `multiprocessing.connection` cu un backend de Unix
socket.

Daemonul pur si simplu se conecteaza la socket-ul creat de server si citeste
linii de pe seriala, parsandule pe cele relevante si salvand informatia pana
cand are destula (data/timp + lat/lon) cat sa trimita pe socket server-ului.

Singura problema pe care o mai am este ca nu am reusit sub nici o forma sa fac
sa recunoasca tema2.local de pe Linuxul meu local (cu pachetele relevante
instalate). Sper sa nu fie o problema prea mare.

Cam atat, salut!
