#include <fstream>
#include <vector>
#include <cstdio>
#include <unordered_map>

using namespace std;

FILE *fin = fopen("magazin.in", "r");
FILE *fout = fopen("magazin.out", "w");

static constexpr int NMAX = (int)1e5 + 5;
vector<int> adj[NMAX];
int index = 0;

void DFS(int src, vector<int> &order,
            vector<int> &hm, vector<int> &available) {
    for (int i = 0; i < adj[src].size(); i++) {
        index++;
        hm[adj[src][i]] = index;
        order[index] = adj[src][i];
        DFS(adj[src][i], order, hm, available);
        available[adj[src][i]] = index;
    }
}

int main() {
    int n, q, d, e, parent;
    fscanf(fin, "%d%d", &n, &q);

    for (int i = 2; i <= n; i++) {
        fscanf(fin, "%d", &parent);
        adj[parent].push_back(i);
    }

    vector<int> hm(n + 1, 0);
    vector<int> available(n + 1, 0);
    vector<int> order(n + 1, 0);
    order[index] = 1;
    hm[1] = index;
    available[1] = n;
    DFS(1, order, hm, available);

    for (int i = 0; i < q; i++) {
        fscanf(fin, "%d%d", &d, &e);
        int pos = hm[d];
        if (pos + e > available[d] || pos + e >= n)
            fprintf(fout, "-1\n");
        else
            fprintf(fout, "%d\n", order[pos + e]);
    }

    fclose(fin);
    fclose(fout);
    return 0;
}
