#include <bits/stdc++.h>
using namespace std;

template <typename T>
using MinHeap = priority_queue<T, vector<T>, greater<T>>;


ifstream fin("teleportare.in");
ofstream fout("teleportare.out");

uint64_t cmmmc(uint64_t a, uint64_t b) {
    uint64_t a1 = a, b1 = b;
    while (b1) {
        uint64_t rest = a1 % b1;
        a1 = b1;
        b1 = rest;
    }
    return a * b / a1;
}

int main() {
    uint64_t n, m, k, x, y, t, copy;
    fin >> n >> m >> k;
    vector<pair<uint64_t, uint64_t>> adj[9][n + 1];
    uint64_t big_cmmmc = 1;
    vector<int> timp_cmmmc(9, 0);

    for (uint64_t i = 0; i < m; i++) {
        fin >> x >> y >> t;
        adj[0][x].push_back({y, t});
        adj[0][y].push_back({x, t});
    }

    for (uint64_t i = 0; i < k; i++) {
        fin >> x >> y >> t;
        adj[t][x].push_back({y, 1});
        adj[t][y].push_back({x, 1});
        timp_cmmmc[t]++;
    }

    for (short i = 1; i <= 8; i++) {
        if (timp_cmmmc[i] > 0) {
            big_cmmmc = cmmmc(big_cmmmc, i);
        }
    }
    vector<vector<uint64_t>> modulo_check(big_cmmmc + 1,
                        vector<uint64_t>(n + 1, INT64_MAX));


    MinHeap<pair<uint64_t, uint64_t>> hp;
    /* distanta - sursa */
    hp.push({0, 1});
    pair<uint64_t, uint64_t> aux, aux2;

    while (1) {
        aux = hp.top();
        if (aux.first > modulo_check[aux.first % big_cmmmc][aux.second]) {
            hp.pop();
            continue;
        }
        modulo_check[aux.first % big_cmmmc][aux.second] = true;
        if (aux.second == n) {
            fout << aux.first;
            break;
        }
        hp.pop();
        for (uint64_t i = 0; i < adj[0][aux.second].size(); i++) {
            aux2.first = aux.first + adj[0][aux.second][i].second;
            aux2.second = adj[0][aux.second][i].first;
            if (aux2.first > modulo_check[aux2.first % big_cmmmc][aux2.second])
                continue;
            modulo_check[aux2.first % big_cmmmc][aux2.second] = aux2.first;
            hp.push(aux2);
        }
        for (short p = 1; p <= 8; p++) {
            if (aux.first % p == 0) {
                for (uint64_t i = 0; i < adj[p][aux.second].size(); i++) {
                    aux2.first = aux.first + adj[p][aux.second][i].second;
                    aux2.second = adj[p][aux.second][i].first;
                    if (aux2.first >
                            modulo_check[aux2.first % big_cmmmc][aux2.second])
                        continue;
                    modulo_check[aux2.first%big_cmmmc][aux2.second]=aux2.first;
                    hp.push(aux2);
                }
            }
        }
    }

    fin.close();
    fout.close();
    return 0;
}
