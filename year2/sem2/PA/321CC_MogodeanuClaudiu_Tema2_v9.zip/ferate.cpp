#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream fin("ferate.in");
ofstream fout("ferate.out");

static constexpr int NMAX = (int)1e5 + 5;
vector<int> adj[NMAX];
int components = 0;
int timp = 0;
stack<int> st;
vector<bool> valid_component;
int source_component;

void DFS(int nod, int n, int m, vector<int> &found, vector<int> &low,
                vector<bool> &in_st, vector<int> &associated_component, int s) {
    found[nod] = low[nod] = ++timp;
    st.push(nod);
    in_st[nod] = true;

    for (int neigh = 0; neigh < adj[nod].size(); neigh++) {
        if (found[adj[nod][neigh]] == -1) {
            DFS(adj[nod][neigh], n, m, found,
                    low, in_st, associated_component, s);
            low[nod] = min(low[nod], low[adj[nod][neigh]]);
        } else if (in_st[adj[nod][neigh]]) {
            low[nod] = min(low[nod], low[adj[nod][neigh]]);
        }
    }

    if (low[nod] == found[nod]) {
        while (in_st[nod]) {
            if (st.top() == s)
                source_component = components;
            in_st[st.top()] = false;
            associated_component[st.top()] = components;
            st.pop();
        }
        valid_component.push_back(true);
        components++;
    }
}

int main() {
    int n, m, s, x, y, count = 0;
    fin >> n >> m >> s;

    for (int i = 0; i < m; i++) {
        fin >> x >> y;
        adj[x].push_back(y);
    }

    vector<int> found(n + 1, -1);
    vector<int> low(n + 1, INT32_MAX);
    vector<bool> in_st(n + 1, false);
    vector<int> associated_component(n + 1, 0);

    DFS(s, n, m, found, low, in_st, associated_component, s);
    for (int i = 1; i <= n; i++) {
        if (found[i] == -1) {
            DFS(i, n, m, found, low, in_st, associated_component, s);
        }
    }

    for (int i = 1; i <= n; i++) {
        for (int j = 0; j < adj[i].size(); j++) {
            if (associated_component[i] != associated_component[adj[i][j]]) {
                valid_component[associated_component[adj[i][j]]] = false;
            }
        }
    }

    valid_component[source_component] = false;
    for (int i = 0; i < components; i++) {
        if (valid_component[i] == true)
            count++;
    }

    fout << count << '\n';
    fin.close();
    fout.close();
    return 0;
}
