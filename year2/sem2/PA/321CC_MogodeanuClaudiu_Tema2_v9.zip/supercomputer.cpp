#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("supercomputer.in");
ofstream fout("supercomputer.out");

static constexpr int NMAX = (int)1e5 + 5;
vector<int> adj[NMAX];

int main() {
    int n, m, u, v;
    fin >> n >> m;
    vector<int> task(n + 1, 0);
    vector<int> dependinte1(n + 1, 0);
    vector<int> dependinte2(n + 1, 0);
    vector<queue<int>> q(3);
    int current_task = 1;
    int count1 = 0, count2 = 0;

    for (int i = 1; i <= n; i++) {
        fin >> task[i];
    }

    for (int i = 0; i < m; i++) {
        fin >> u >> v;
        adj[u].push_back(v);
        dependinte1[v]++;
        dependinte2[v]++;
    }

    for (int i = 1; i <= n; i++) {
        if (dependinte1[i] == 0) {
            if (task[i] == 1)
                q[1].push(i);
            else
                q[2].push(i);
        }
    }

    while (!q[1].empty() || !q[2].empty()) {
        if (q[current_task].empty()) {
            current_task = 3 - current_task;
            count1++;
        }
        int scos = q[current_task].front();
        q[current_task].pop();

        for (int i = 0; i < adj[scos].size(); i++) {
            dependinte1[adj[scos][i]]--;
            if (dependinte1[adj[scos][i]] == 0) {
                q[task[adj[scos][i]]].push(adj[scos][i]);
            }
        }
    }

    current_task = 2;
    for (int i = 1; i <= n; i++) {
        if (dependinte2[i] == 0) {
            if (task[i] == 1)
                q[1].push(i);
            else
                q[2].push(i);
        }
    }

    while (!q[1].empty() || !q[2].empty()) {
        if (q[current_task].empty()) {
            current_task = 3 - current_task;
            count2++;
        }
        int scos = q[current_task].front();
        q[current_task].pop();

        for (int i = 0; i < adj[scos].size(); i++) {
            dependinte2[adj[scos][i]]--;
            if (dependinte2[adj[scos][i]] == 0) {
                q[task[adj[scos][i]]].push(adj[scos][i]);
            }
        }
    }
    fout << min(count1, count2);

    fin.close();
    fout.close();
    return 0;
}
