:- ensure_loaded('points1.pl').
:- ensure_loaded('utils.pl').
:- ensure_loaded('testing.pl').
:- ensure_loaded('checker.pl').
