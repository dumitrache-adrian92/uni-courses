#include <stdio.h>
void ignition(char *param_1);
void print_code(char *param_1);
void starship(void *param_1,int param_2);




int main(void)
{

  // TODO c)
  starship("into the darkness",0xabadbabe);
	return 0;
}
