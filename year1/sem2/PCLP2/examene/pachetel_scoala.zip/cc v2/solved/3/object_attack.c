#include <stdio.h>

void order_please(char *param_1,int param_2);

int main () {
    /* call hidden function from object.o with the "key1 key2" argument */
    order_please("johns pizzeria", 0xf00dbabe);
    return 0;
}
