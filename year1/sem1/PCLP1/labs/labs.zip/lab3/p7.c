#include <stdio.h>

void main()
{
    int n;
    double eps, x;
    scanf ("%lf%d%lf", x, n, eps);
    
}