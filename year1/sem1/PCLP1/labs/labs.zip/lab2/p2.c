#include <stdio.h>

void main()
{
    float f, e, g;
    scanf("%f%e%g", &f, &e, &g);
    printf("%f %e %g\n", f, e, g);
}