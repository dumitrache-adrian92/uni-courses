#include <stdio.h>

int main()
{
    printf("Programarea Calculatoarelor\n");
    return 0; 
}