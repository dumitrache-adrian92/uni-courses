#!/bin/bash
singularity exec $CONTAINER_IMAGE  \
./$TASK
